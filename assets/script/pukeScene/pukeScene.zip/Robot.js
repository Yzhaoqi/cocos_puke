var com = require('GameDefine');

// 选择分值
exports.selectPoint = (seat, pointToChoose, self) => {
    setTimeout(()=>{
        self.node.emit(com.ON_SELECT_NEXT, {num: seat, point: pointToChoose[0]});
    }, 200);
}

exports.pushCard = (zone, gameLogic, gameDisplay, node, self) => {
    setTimeout(() => {
        var array = getPushCard(zone, gameLogic);

        if (array.length != 0) {
            gameLogic.setCurrentCard(array);
            gameLogic.pushCards();
            zone.pickCards(array);
            gameDisplay.changeCardNum(zone.getHandCardNum(), node);
            self.otherPushCard(zone, node);
            self.hasPushCard();
        } else {
            self.passCard();
        }  
    }, 200);
}


/**
 * TODO ：先考虑一个最简单的跟牌AI
 * 根据上家出的牌出手中最小的符合相应类型的牌
 * zone ：牌区， 相关可调用的方法（可参考MediumZone.js）
 *              zone.getHandCardNum()返回自己手牌的数量
 *              zone.getHandCards()返回自己的手牌数组
 * gameLogic ：游戏逻辑，存放游戏相关的信息（可参考GameLogic.js）
 *              gameLogic.getLastCard() 返回以下对象：
 *                  {type：上家出牌的类型， num：上家出牌的数量，value：上家出牌的值} type参见GameDefine中的定义。
 *              gameLogic.getValue(cardVal) 返回一张卡的值
 */
var getPushCard = function(zone, gameLogic) {
    var currentCard = zone.getHandCards();
    var num = zone.getHandCardNum();
    var last = gameLogic.getLastCards();

    var array = [], currentCardValue = []; // currentCardValue
    for (var i = 0; i < num; i++) {
        currentCardValue[i] = gameLogic.getValue(currentCard[i]);
    }
    switch(last.type) {
        case com.TYPE_NOT_VALID: case com.TYPE_SINGLE:
            for (var i = 0; i < num; i++) {
                if (currentCardValue[i] > last.value) {
                    array[0] = currentCard[i];
                    return array;
                }
            }
        break;
        // TODO: 对更多的case进行讨论。
    }
    return [];
}